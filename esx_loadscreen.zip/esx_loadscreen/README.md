# Flashline Loadscreen v1.0.0

**Description :** Loadscreen interactif pour FiveM avec slideshow, musique, barre de chargement et logos réseaux.

## Installation
1. Copier le dossier `esx_loadscreen` dans votre dossier `resources`.
2. Ajouter `ensure esx_loadscreen` dans votre `server.cfg`.

## Configuration
- Modifier `config.lua` si nécessaire (Fade, musique, etc.).
- Modifier `index.html`
- Modifier `style.css`

## Support
Contactez sur Discord.






