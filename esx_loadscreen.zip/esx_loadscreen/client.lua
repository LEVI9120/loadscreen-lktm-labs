local ClientLoadESX = false

-- Thread pour activer le curseur dès le loadscreen
Citizen.CreateThread(function()
    while not ClientLoadESX do
        SetNuiFocus(true, true)       -- Active le curseur et le focus NUI
        SetNuiFocusKeepInput(true)    -- Permet de garder le focus même si l'utilisateur clique ailleurs
        Citizen.Wait(0)               -- Répète chaque frame
    end
end)

-- Quand le joueur spawn, on ferme le loadscreen
AddEventHandler("playerSpawned", function()
    if not ClientLoadESX then
        ClientLoadESX = true

        -- Option fade si configurée
        if Config and Config.Fade then
            DoScreenFadeOut(0)
            Wait(3000)
            DoScreenFadeIn(2500)
        end

        -- Ferme le loadscreen NUI
        ShutdownLoadingScreenNui()

        -- Désactive le curseur
        SetNuiFocus(false, false)
    end
end)






