const config = {
    videoBackground: "video/background.mp4", // vidéo locale mp4
    logo: "images/logo.png",
    music: {
        type: "mp3",
        source: "audio/musique.mp3", // fichier audio
        autoplay: true,
        loop: true
    }
};

