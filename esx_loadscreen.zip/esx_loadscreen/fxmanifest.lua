fx_version 'cerulean'
game 'gta5'

author 'ltkm labs'
description 'Loadscreen ltkm labs'
version '1.0.0'

loadscreen 'index.html'

shared_script 'config.lua'

loadscreen_manual_shutdown "yes"

client_scripts {
    'client.lua'
}

files {
    'index.html',
    'style.css',
    'script.js',
    'images/logo.png',
    'images/image1.jpg',
    'images/image2.jpg',
    'images/image3.jpg',
    'images/image4.jpg',
    'images/image5.jpg',
    'images/image6.jpg',
    'images/image7.jpg',
    'images/discord.jpg',
    'images/tiktok.jpg',
    'images/twitch.jpg',
    'audio/musique.mp3'
}


loadscreen 'yes'
loadscreen_cursor 'yes'


