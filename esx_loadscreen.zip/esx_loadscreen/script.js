window.onload = function() {
    // === Musique automatique ===
    const music = new Audio("audio/musique.mp3");
    music.loop = true;
    music.volume = 0.5;

    music.play().catch(() => {
        console.log("Le navigateur bloque l'autoplay, il faudra cliquer pour jouer la musique.");
    });

    // === Slideshow ===
    let slides = document.querySelectorAll(".slide");
    let currentSlide = 0;

    function nextSlide() {
        slides[currentSlide].classList.remove("active");
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add("active");
    }
    setInterval(nextSlide, 5000);

    // === Barre de chargement ===
    const progress = document.getElementById("progress");
    let width = 0;

    const fakeProgress = setInterval(() => {
        if (width < 80) {
            width++;
            progress.style.width = width + "%";
        }
    }, 100);

    // === Réception du signal serveur ===
    window.addEventListener("message", (event) => {
        if (event.data.type === "loadscreenDone") {
            clearInterval(fakeProgress);
            progress.style.width = "100%";
            document.getElementById("loading-bar").style.display = "none";
            document.getElementById("loading-text").style.display = "none";
        }

        if (event.data.type === "focus") {
            window.focus();
            document.body.style.cursor = "auto";
        }
    });
};


